
package com.felipin.calculadora.etec;

public class ConversorNumeros {
    public Integer stringToInt(String num){
        int conversor = Integer.parseInt(num);
        return(conversor);
    }
    
    public Double stringToDouble(String num){
        double conversor=Double.parseDouble(num);
        return(conversor);
    }
}
