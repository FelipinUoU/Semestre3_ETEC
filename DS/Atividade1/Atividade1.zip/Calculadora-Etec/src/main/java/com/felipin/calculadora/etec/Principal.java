
package com.felipin.calculadora.etec;

public class Principal {
    	public static void main(String[] args){
            Menu menuPrincipal = new Menu();
            menuPrincipal.executarCaixa();
	}
}

